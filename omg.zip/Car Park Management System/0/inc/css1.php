<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
     
 <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
<link rel="stylesheet" href="styles/styles.css" type="text/css" />
<link rel="stylesheet" href="styles/pager.css" type="text/css" />