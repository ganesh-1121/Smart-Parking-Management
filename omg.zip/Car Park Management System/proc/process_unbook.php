<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
    include('../inc/connect.php');

    if (isset($_POST['booking'])) {
        $booking_id = $_POST['booking'];

        // Delete the selected booking from the database
        $delete_query = mysqli_query($connect, "DELETE FROM zones WHERE id='$booking_id'");
        
        if ($delete_query) {
            // Booking successfully deleted, redirect to success_unbook.php
            header("Location: success_unbook.php");
            exit;
        } else {
            // Error occurred while deleting booking
            echo "Error: Unable to unbook the parking lot.";
        }
    } else {
        // No booking selected
        echo "Error: No booking selected.";
    }
} else {
    // Session not started
    echo "Error: Session not started.";
}
?>
