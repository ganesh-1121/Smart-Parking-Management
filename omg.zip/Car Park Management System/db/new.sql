CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plot_id INT,
    start_datetime DATETIME,
    end_datetime DATETIME
);
